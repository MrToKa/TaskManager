using System;
using System.Collections.Generic;
using System.Linq;

namespace TaskManager
{
    public class Manager : IManager
    {
        public Dictionary<string, Task> tasks = new Dictionary<string, Task>();
        public Dictionary<string, List<string>> dependencies = new Dictionary<string, List<string>>();

        //Adds a dependency between two tasks. The task with taskId depends on the task with dependentTaskId. If either task doesn't exist or if a circular dependency is created, throw an ArgumentException. Circular dependency meaning that if A depends on B, then B cannot depends on A. Keep in mind, that new dependency carries other dependencies too.If A depends on B, and B depends on C, then A depends on C indirectly.
        public void AddDependency(string taskId, string dependentTaskId)
        {
            if (tasks.ContainsKey(taskId) && tasks.ContainsKey(dependentTaskId))
            {
                if (dependencies.ContainsKey(taskId))
                {
                    dependencies[taskId].Add(dependentTaskId);
                }
                else
                {
                    dependencies.Add(taskId, new List<string>() { dependentTaskId });
                }
            }
            else
            {
                throw new ArgumentException();
            }

        }

        //adds a task to the task manager. If a task with the same ID already exists, throw an ArgumentException.
        public void AddTask(Task task)
        {
            if (tasks.ContainsKey(task.Id))
            {
                throw new ArgumentException();
            }
            tasks.Add(task.Id, task);
        }

        //returns whether the task manager contains the specified task.
        public bool Contains(string taskId)
        {
            return tasks.ContainsKey(taskId);
        }

        //returns the task in the system. If no task with that ID exists, throw an ArgumentException
        public Task Get(string taskId)
        {
            if (tasks.ContainsKey(taskId))
            {
                return tasks[taskId];
            }
            throw new ArgumentException();
        }

        //Returns all tasks that the task with the given taskId depends on.If the taskId does not exist, return empty collection.If A depends on B, and A depends on C: All dependencies for A are B and C. B and C do not have any dependencies.
        public IEnumerable<Task> GetDependencies(string taskId)
        {
            var result = new List<Task>();
            var stack = new Stack<string>();
            stack.Push(taskId);

            while (stack.Count > 0)
            {
                var currentTaskId = stack.Pop();
                if (dependencies.TryGetValue(currentTaskId, out var dependentTaskIds))
                {
                    foreach (var dependentTaskId in dependentTaskIds)
                    {
                        if (tasks.TryGetValue(dependentTaskId, out var task))
                        {
                            result.Add(task);
                            stack.Push(dependentTaskId);
                        }
                    }
                }
            }

            return result;
        }

        private List<Task> GetDependencies(string taskId, List<Task> tasks)
        {
            if (dependencies.ContainsKey(taskId))
            {
                foreach (var item in dependencies[taskId])
                {
                    if (this.tasks.ContainsKey(item))
                    {
                        tasks.Add(this.tasks[item]);
                        GetDependencies(item, tasks);
                    }
                }
            }
            return tasks;
        }

        //Returns all tasks that depend on the specified taskId. If the taskId does not exist, return empty collection. If A depends on B, and A depends on C: A does not have any dependants. B has A as a dependant.C has A as a dependant.
        public IEnumerable<Task> GetDependents(string taskId)
        {
            var result = new List<Task>();

            GetDependents(taskId, result);

            return result;
        }

        private List<Task> GetDependents(string taskId, List<Task> result)
        {
            foreach (var item in dependencies)
            {
                if (item.Value.Contains(taskId))
                {
                    result.Add(tasks[item.Key]);
                    GetDependents(item.Key, result);
                }
            }
            return result;
        }

        //Removes a dependency between two tasks. If either task doesn't exist or if there is no dependency between them, throw an ArgumentException. 
        public void RemoveDependency(string taskId, string dependentTaskId)
        {
            if (tasks.ContainsKey(taskId) && tasks.ContainsKey(dependentTaskId))
            {
                if (dependencies.ContainsKey(taskId))
                {
                    dependencies[taskId].Remove(dependentTaskId);
                }
                else
                {
                    throw new ArgumentException();
                }
            }
            else
            {
                throw new ArgumentException();
            }
        }

        //removes the task with the given ID from the task manager. If no task with that ID exists, throw an ArgumentException
        public void RemoveTask(string taskId)
        {
            if (!tasks.ContainsKey(taskId))
            {
                throw new ArgumentException();
            }
            tasks.Remove(taskId);
            dependencies.Remove(taskId);

            foreach (var item in dependencies)
            {
                if (item.Value.Contains(taskId))
                {
                    item.Value.Remove(taskId);
                }
            }
        }

        //returns the total count of all tasks in the task manager
        public int Size()
        {
            return tasks.Count;
        }
    }
}